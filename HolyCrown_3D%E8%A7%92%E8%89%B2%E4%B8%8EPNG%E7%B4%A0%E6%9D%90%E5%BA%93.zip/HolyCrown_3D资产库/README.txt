HOLY CROWN / 圣冠 — 3D + PNG 角色资产原型包
================================================

内容
----
HolyCrown_圣冠_3D版.html   游戏整合版（基于原角色外观系统版）
models/*.glb                可独立导入 Blender / Godot / Unity 的 GLB 网格模块
png/body/                   男女基础身体透明 PNG
png/hair/                   6 款发型透明 PNG
png/armor/                  护甲、头盔、披风透明 PNG
png/weapons/                武器透明 PNG
png/icons/                  PNG 小图标
materials/                  材质色板 PNG

当前 3D 模块
------------
male_base.glb / female_base.glb
hair_swept.glb / hair_long.glb / hair_braid.glb / hair_short.glb / hair_silver.glb / hair_tied.glb
armor_oathsteel.glb / helmet_oathsteel.glb / cape_crimson.glb / sword_oathsteel.glb

运行方法
--------
3D 预览使用 Three.js CDN，并从 models/ 读取 GLB 文件。请保持 HTML、models、png、materials 的相对目录结构。
不要直接双击 HTML（file:// 可能阻止模块和 GLB 读取）。在此目录打开终端运行：

  python -m http.server 8000

然后浏览器打开： http://localhost:8000/HolyCrown_%E5%9C%A3%E5%86%A0_3D%E7%89%88.html

技术说明 / 当前限制
------------------
这是可运行的第一版模块化 3D 原型：GLB 由程序化网格构成，角色可以旋转查看，发型和护甲/头盔/披风/武器可分别开关；PNG 为透明底的独立素材原型。
它还不是影视级/AAA 高精度雕刻模型，也没有完整骨骼绑定、动作动画、面部表情系统或完整 PBR 贴图集。PNG 目前是统一风格的简化图形素材，不应误认为最终商业级角色原画。
后续精修时可在 Blender 中细化模型、拓扑、UV、骨骼与材质，再导出 GLB 替换 models/ 内同名文件；PNG 可逐件替换，目录和文件名保持不变即可。
